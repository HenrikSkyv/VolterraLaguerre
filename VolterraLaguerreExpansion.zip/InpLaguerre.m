function [XReg] = InpLaguerre(Inp1,Inp2,order,NumFilt,Alpha,type)
% Maing structured regularization matrix for the Laguerrian Volterra-model
%Inp1 = input 1(1xN)
%Inp2 = input2(1xN or empty of type = direct)
%order = order of the model, integer <5
%NumFilt = Laguerrian filter number to be used, integer
%Alpha = Alpha factor for the Laguerrian filters, float between 0 and 1
%type = 'direct','cross','crossDirect' dependent on the Volterra type(SISO,
%MISO with cross terms, MISO without cross-terms)

%Outputs:
%XReg = regularization matrix

%Test to check model order
if order >4
    error('5th order or higher not goint to be implemented due to lack of regurius mathematical treatment')
end
%%


xx1 = NaN;
xx2 = NaN;
XReg = NaN;
%Recursion function, making the filter functions and combining with the
%input to make basis for regression matrix. Equation: 7.27/7.28

xx1 = zeros([NumFilt length(Inp1)]);
for i = 1:1:length(Inp1)-1
% 0-order filter    
xx1(1,1)=0;
xx1(1,i+1)=sqrt(Alpha)*xx1(1,i)+sqrt(1-Alpha)*Inp1(i+1);

% >0order filters
for j = 2:1:NumFilt
xx1(j,1)=0;
xx1(j,i+1)=sqrt(Alpha)*xx1(j,i)+sqrt(Alpha)*xx1(j-1,i+1) - xx1(j-1,i);
end
end

%% Cross

%Recursion function, making the filter functions and combining with the
%input to make basis for regression matrix. Equation: 7.27/7.28

xx2 = zeros([NumFilt length(Inp2)]);
for i = 1:1:length(Inp2)-1
% 0-order filter    
xx2(1,1)=0;
xx2(1,i+1)=sqrt(Alpha)*xx2(1,i)+sqrt(1-Alpha)*Inp2(i+1);

% >0order filters
for j = 2:1:NumFilt
xx2(j,1)=0;
xx2(j,i+1)=sqrt(Alpha)*xx2(j,i)+sqrt(Alpha)*xx2(j-1,i+1) - xx2(j-1,i);
end
end



%% Combining the input to get the full regression matrix, direct
if strcmp(type, 'direct')
    XX = xx1'; 
    XX1 = ones([1 length(Inp1)])';   
    XXX = [XX1 XX];                 

    if order == 1    
        XReg = XXX;
    end
    % Making the first part =[Filt1 Filt1 Filt1... Filt2 Filt2 Filt2... Filtn]
    Index = 0;
    for m = 1:1:NumFilt
        for n =1:1:NumFilt
            Index = Index + 1;        
            XXXa(:,Index)=XX(:,m);
        end
    end
    %making the second part = [Filt1 Filt2 Filt3... Filt1 Filt2 Filt3... ] 
    XXXb=repmat(XX,1,NumFilt);
    XXXc = XXXa.*XXXb;
    XXXX = [XXX XXXc];  

    if order == 2
        XReg = XXXX;
    end    
    %Implement 3rd order: 
    if order > 2
        X3a = repmat(XXXc,1,NumFilt);
       
        
        X3b = [];
        for p = 1:1:NumFilt
            
            X3b = [X3b repmat(XX(:,p),1,NumFilt^2)];
        
        end
        
        X3 = X3a.*X3b;
       
        XReg = [XXXX X3];
        
        
        
    end
    
    if order > 3
        X4a = repmat(X3a,1,NumFilt);
        
        X4b = [];
        for p = 1:1:NumFilt
            X4b = [X4b repmat(XX(:,p),1,NumFilt^3)];
                
        end
        
        X4 = X4a.*X4b;
        
        XReg = [XReg X4];
        
    end
    
           
elseif strcmp(type, 'cross')
    
    XX_1 = xx1'; 
    XX_2 = xx2';
    XX1 = ones([1 length(Inp1)])';  
    XXX = [XX1 XX_1 XX_2];          

    if order == 1    
        XReg = XXX; 
    end
    
    Index = 0;
    for m = 1:1:NumFilt
        for n =1:1:NumFilt
            Index = Index + 1;        
            XXXa_1(:,Index)=XX_1(:,m);
            XXXa_2(:,Index)=XX_2(:,m);
        end
    end
    
    XXXb_1=repmat(XX_1,1,NumFilt);
    XXXb_2=repmat(XX_2,1,NumFilt);
    XXXc_11 = XXXa_1.*XXXb_1;
    XXXc_12 = XXXa_1.*XXXb_2;
    XXXc_21 = XXXa_2.*XXXb_1;
    XXXc_22 = XXXa_2.*XXXb_2;

    
    
    XXXX = [XXX XXXc_11 XXXc_12 XXXc_21 XXXc_22]; 

    
    if order > 1
        XReg = XXXX;
    end    
    %Implement 3rd order: 
    if order > 2
       
        X3a_11 = repmat(XXXc_11,1,NumFilt);
        X3a_22 = repmat(XXXc_22,1,NumFilt);
        
        
        X3b_1 = [];
        X3b_2 = [];
        
        for p = 1:1:NumFilt
            
            X3b_1 = [X3b_1 repmat(XX_1(:,p),1,NumFilt^2)];
            X3b_2 = [X3b_2 repmat(XX_2(:,p),1,NumFilt^2)];
        
        end
        
        X3_111 = X3a_11.*X3b_1;
        X3_112 = X3a_11.*X3b_2;
        X3_221 = X3a_22.*X3b_1;
        X3_222 = X3a_22.*X3b_2;
        
        XReg = [XXXX X3_111 X3_112 X3_221 X3_222];
        
    end
    
        if order > 3
       
        X4a_111 = repmat(X3_111,1,NumFilt);
        X4a_112 = repmat(X3_112,1,NumFilt);
        X4a_222 = repmat(X3_222,1,NumFilt);

        
        
        X4b_1 = [];
        X4b_2 = [];
        
        for p = 1:1:NumFilt
            
            X4b_1 = [X4b_1 repmat(XX_1(:,p),1,NumFilt^3)];
            X4b_2 = [X4b_2 repmat(XX_2(:,p),1,NumFilt^3)];
        
        end
        
        
        
        X4_1111 = X4a_111.*X4b_1;
        X4_1112 = X4a_111.*X4b_2;
        X4_1122 = X4a_112.*X4b_2;
        X4_2221 = X4a_222.*X4b_1;
        X4_2222 = X4a_222.*X4b_2;
        
        XReg = [XReg  X4_1111 X4_1112 X4_1122 X4_2221 X4_2222];
    end
    
    
elseif strcmp(type, 'crossDirect')
    
    XX_1 = xx1'; 
    XX_2 = xx2';
    XX1 = ones([1 length(Inp1)])';    
    XXX = [XX1 XX_1 XX_2];           

    if order == 1    
        XReg = XXX; 
    end
    
    Index = 0;
    for m = 1:1:NumFilt
        for n =1:1:NumFilt
            Index = Index + 1;        
            XXXa_1(:,Index)=XX_1(:,m);
            XXXa_2(:,Index)=XX_2(:,m);
        end
    end
    
    XXXb_1=repmat(XX_1,1,NumFilt);
    XXXb_2=repmat(XX_2,1,NumFilt);
    XXXc_11 = XXXa_1.*XXXb_1;
    XXXc_22 = XXXa_2.*XXXb_2;
    XXXX = [XXX XXXc_11  XXXc_22];  

    
    if order == 2
        XReg = XXXX;
    end    
    
    if order > 2
        X3a_11 = repmat(XXXc_11,1,NumFilt);
        X3a_22 = repmat(XXXc_22,1,NumFilt);
        
        
        X3b_1 = [];
        X3b_2 = [];
        
        for p = 1:1:NumFilt
            
            X3b_1 = [X3b_1 repmat(XX_1(:,p),1,NumFilt^2)];
            X3b_2 = [X3b_2 repmat(XX_2(:,p),1,NumFilt^2)];
        
        end
        
        X3_111 = X3a_11.*X3b_1;
        X3_222 = X3a_22.*X3b_2;
       
        XReg = [XXXX X3_111 X3_222];
        
    end   
    
    if order >3
        X4a_111 = repmat(X3_111,1,NumFilt);
        X4a_222 = repmat(X3_222,1,NumFilt);

        
        
        X4b_1 = [];
        X4b_2 = [];
        
        for p = 1:1:NumFilt
            
            X4b_1 = [X4b_1 repmat(XX_1(:,p),1,NumFilt^3)];
            X4b_2 = [X4b_2 repmat(XX_2(:,p),1,NumFilt^3)];
        
        end
        
        
        
        X4_1111 = X4a_111.*X4b_1;
        X4_2222 = X4a_222.*X4b_2;
        
        XReg = [XReg  X4_1111 X4_2222];
  
    
    end
    
end

end

