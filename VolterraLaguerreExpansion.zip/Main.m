%% VolterraLaguerreExpansion: Bridge relevant numerical example, Laguerrian expansion basis
%
% This file generates data, trains Volterra-moddels with the Laguerrian
% Expansion basis the different plots according to:
% 
%  "Bridge relevant numerical example"
% 
% Please site the following paper when using this code:  
% "The use of a Laguerrian expansion basis as Volterra kernels for the 
% efficient modeling of nonlinear self-excited forces on bridge decks" 
% H.Skyvulstad, �.Petersen, T.Argentini, A. Zasso, O. �iseth
% 
%
%VolterraLaguerreExpansion is a free software: you can use, distribute and
%modyfi at will under the terms of the GNU General public license as published
%by the Free Software Foundation, either version 3 of the license, or (at your option)
%any later version. 

%VolterraLaguerreExpansion is distributed because it might be usefull for others,
%but it comes without any form of WARRANTY; without even the implied 
%warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
%See the GNU General Public License for more details.
%
%A copy of the license is distributed with the code, and can be found here:
%https://www.gnu.org/licenses/.
%
% The code has the following components:
% 1. Generating training data from a simplified rational-function example.
% 2. Training a Volterra-model structure with the Laguerrian expansion
% basis
% 3. Plotting. 
%
% Note that this example only trains Single-Input-Single-Output(SISO) 2nd-order
% Volterra-model, but the Volterra-model structure can be used on
% 4th-order SISO, and 4th order Double-input-single-output models with and
% without cross terms. 
% 
%
% By, PhD-candidate Henrik Skyvulstad, 2021-03-10
% henrik.skyvulstad@norconsult.com / henrik.skyvulstad@ntnu.no



%% 
clc 
close all
clear

%%        INPUTS         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
NumFilt=3;                                  %Filter order(number of Laguerrian filters to be included)
Alpha = 0.909; %float between 0 and 1       %Alpha factor determining the shape of the filters
Order = 2; %{1, 2, 3 or 4}                  %Order of the model. PS. The training data-set is only 2nd-order but the code can handle up to 4th order models
type = 'direct';  %'direct' , 'cross' or 'crossDirect'       %Type of Volterra-model used: 'direct' = Single-input-single-output, 'cross' = Double-input-single-output with cross-terms, 'crossDirect' = Double-input-single-output without cross-terms
M = 140;                                    %Memory length of the kernel(not the Volterra-model this is determined by the Alpha-factor)
d = 1;                                      %d-value for the rational function in time domain. Se cited paper:    
V = 1;                                      %V-value for the rational function in time domain. Se cited paper:
B = 1;                                      %B-value for the rational function in time domain. Se cited paper:
a1 = 1;                                     %a1 value for scaling of the linear rational function. Se the cited paper. 
a2 = 0.05;                                  %a2 value for scaling of the 2nd-order scaling rational function. Se the cited paper. 
a3 = 0.005;                                 %a3 value
a4 = 0.0005;                                %a4 value
a5 = 0.00005;                               %a5 value
SNR = 0.1;                                  % Signal to noise ratio, based on variances on the signals
dt = 0.05;                                  % time-increment
TraininSignalLength = 100000;               %Training data length (also validation data lengths)

%% Generating the analytical kernels
t = dt*(1:1:TraininSignalLength);
t2 = 0:dt:dt*(M+1);
for i = 1:1:M+1
    H1(i) = -d*V/B*exp((-d*V/B)*t2(i));
    for j = 1:1:M+1 
    H2(i,j) = a2*(-d*V/B*exp((-d*V/B)*t2(i))*-d*V/B*exp((-d*V/B)*t2(j)));
    end
end

%%  Generating the training data
Input = wgn(TraininSignalLength,1,0);
Noise = wgn(TraininSignalLength,1,0);
ValidationInput = wgn(TraininSignalLength,1,0); 

%Generate training data
Data.RegMatrix = MakeRegressionMatrix(Input,M,1);
F1 = Data.RegMatrix*H1';
F_clean = a1*F1 + a2*F1.^2;

%Scaling the noise according to the variances of the signals
VarOut = var(F_clean);
VarNoise = var(Noise);
F_noisy = F_clean + Noise * sqrt((VarOut/VarNoise))*SNR;

%Generate signal with higher order correlated noise
F_high = F_clean + a3*F1.^3 + a4*F1.^4+a5*F1.^5;

% Generate Validation data
ValidationData.RegMatrix = MakeRegressionMatrix(ValidationInput,M,1);
F1Valid = ValidationData.RegMatrix*H1';
F_Valid = a1*F1Valid + a2*F1Valid.^2;


%% Training the Volterra-models


%Making a Laguerre class
VoltClean = Laguerre;

%The Laguerre class has the following training the model
%TrainLaguerreFull(Input1, Inpu2, Output, Memory, Order,
%NumberOfLaguerreFIlters, AlphaFactor, Volterra-Type)
%%%%Inputs:%%%%%
%Input1 = First input(motion)
%Input2 = 2nd-input, can be set to empty if 'direct' type is used
%Output = Vector of outputs for training
%Memory = Memory lengths of the model(only for plotting the kernels, no
%effect in the actual model
%NumberOfLaguerreFilters = Number of Laguerrian filters to parameterize
%the kernel
%Order = Order of the Volterra-model
%Alpha = Alpha factor of the model
%Volterra-type = 'direct'/'cross'/'crossDirect' to decide of the type of
%the Volterra-model(SISO / Double-input-single-output with cross / double
%input single-output without cross-terms)
%%%%%Outputs:%%%%
%Outputs a trained model, with various properties as kernels. Se the class
%for all properties
VoltClean.TrainLaguerreFull(Input,[],F_clean,M,2,NumFilt,Alpha,'direct')

VoltNoisy = Laguerre;
VoltNoisy.TrainLaguerreFull(Input,[],F_noisy,M,2,NumFilt,Alpha,'direct')

VoltHigh = Laguerre;
VoltHigh.TrainLaguerreFull(Input,[],F_high,M,2,NumFilt,Alpha,'direct')


%% Using the model on independen validation data

%Uses the ValidateLaguerre model to make a realization of the already
%trained model:
%ValidateLaguerre(Input1,Input2)
%Input1 = first input of validation data
%input 2 = second input of validation data(can be empty dependent on the
%type of model
VoltClean.ValidateLaguerre(ValidationInput,[]);
PredClean = VoltClean.YPred{end};

VoltNoisy.ValidateLaguerre(ValidationInput,[]);
PredNoisy = VoltNoisy.YPred{end};

VoltHigh.ValidateLaguerre(ValidationInput,[]);
PredHigh = VoltHigh.YPred{end};

%Checking the performance of the model
NMSE_Clean = goodnessOfFit(F_Valid,VoltClean.YPred{end},'NMSE');
NMSE_Noisy = goodnessOfFit(F_Valid,VoltNoisy.YPred{end},'NMSE');
NMSE_High = goodnessOfFit(F_Valid,VoltHigh.YPred{end},'NMSE');

%Print it in a table structure
NMSE_data = [NMSE_Clean,NMSE_Noisy,NMSE_High];
ModelNames = {'VoltClean','VoltNoisy','VoltHigh'};
VarNames = {'Model','NMSE'};
T = table(NMSE_data',ModelNames','VariableNames',VarNames);
disp(T)

%% %%%%%%%%% Start plotting  %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Get the diagonals of the 2nd order kernels
H2diagAnalytical = diag(H2);
H2diagNoisy = diag(VoltNoisy.HH11);
H2diagClean = diag(VoltClean.HH11);
H2diagHigh = diag(VoltHigh.HH11);
MemoryGrid = 1:1:M+1;

%% Plotting the kernels in discrete-time domain
fig ure()
title(['Signal to noise =' num2str(SNR)])
subplot(3,2,1)
plot(MemoryGrid, H1,'*', MemoryGrid, VoltClean.HH1, MemoryGrid, VoltNoisy.HH1,'+',MemoryGrid, VoltHigh.HH1)
legend('Analytical','SNR=\infty','SNR=10','HO.Noise','location','southeast', 'interpreter','tex')
xlim([0 150]);
ylabel('h_1')
xlabel('Memory,(M)')
grid on


subplot(3,2,2)
plot(MemoryGrid, H2diagAnalytical,'*', MemoryGrid, H2diagClean, MemoryGrid, H2diagNoisy, '+', MemoryGrid, H2diagHigh)
legend('Analytical','SNR=\infty','SNR=10','HO.Noise', 'interpreter','tex')
xlim([0 150]);
ylabel('h_2 diagonal')
xlabel('Memory,(M_1=M_2)')
grid on

subplot(3,2,3)
surf(H2,'EdgeColor','interp')
view(73,31)
xlim([0 150]);
ylim([0 150]);
zlabel('h_2 Analytical')

subplot(3,2,4)
surf(VoltClean.HH11,'EdgeColor','interp')
view(73,31)
xlim([0 150]);
ylim([0 150]);
zlabel('h_2 SNR=\infty', 'interpreter','tex')

subplot(3,2,5)
surf(VoltNoisy.HH11,'EdgeColor','interp')
view(73,31)
xlim([0 150]);
ylim([0 150]);
zlabel('h_2 SNR=10')
xlabel('Memory,(M_1)')
ylabel('Memory,(M_2)')


subplot(3,2,6)
surf(VoltHigh.HH11,'EdgeColor','interp')
view(73,31)
xlim([0 150]);
ylim([0 150]);
zlabel('h_2 HO.Noise')
xlabel('Memory,(M_1)')
ylabel('Memory,(M_2)')



%% Plotting the validation data in time-domain
figure()
plot(t,F_Valid,t,PredClean,t,PredNoisy,t,PredHigh)
legend('Data',['SNR=\infty, NMSE =' num2str(round(NMSE_Clean,3))],['SNR=10, NMSE =' num2str(round(NMSE_Noisy,3))],['HO.Noise, NMSE =' num2str(round(NMSE_High,3))],'box','off','Orientation','horizontal', 'interpreter','tex')
xlim([210 250])
xlabel('Time(sec)')
ylabel('F(N)')
grid on


%% Plotting the kernels in frequency domain
Fs = 1/dt;
N = length(H2);
k=0:N-1; 
T = N/Fs;
freq = k/T;
freq = freq - mean(freq);
[X,Y]=meshgrid(freq,freq);


FFT2Analytical = abs(fftshift(fft2(H2)));
FFT2Clean = abs(fftshift(fft2(VoltClean.HH11)));
FFT2Noisy = abs(fftshift(fft2(VoltNoisy.HH11)));
FFT2High = abs(fftshift(fft2(VoltHigh.HH11)));

[FFT1Analytical,freq1] = pfft(H1,Fs);
[FFT1Clean,~] = pfft(VoltClean.HH1,Fs);
[FFT1Noisy,~] = pfft(VoltClean.HH1,Fs);
[FFT1High,~] = pfft(VoltClean.HH1,Fs);


FFT1Analytical = abs(FFT1Analytical);
FFT1Clean = abs(FFT1Clean);
FFT1Noisy = abs(FFT1Noisy);
FFT1High = abs(FFT1High);

DiagFFT2Analycical = diag(FFT2Analytical);
DiagFFT2Clean = diag(FFT2Clean);
DiagFFT2Noisy = diag(FFT2Noisy);
DiagFFT2High = diag(FFT2High);

figure()
subplot(3,2,1)
plot(freq1,FFT1Analytical,'*',freq1,FFT1Clean,freq1,FFT1Noisy,'+',freq1,FFT1High)
legend('Analytical','SNR=\infty','SNR=10','HO.Noise','location','northeast','box','off','interpreter','tex')
ylabel('H_1')
xlabel('\omega','Interpreter','tex')
grid on

subplot(3,2,2)
plot(freq,DiagFFT2Analycical,'*',freq,DiagFFT2Clean,freq,DiagFFT2Noisy,'+',freq,DiagFFT2High)
xlim([-5 5]);
ylabel('H_2 diagonal')
xlabel('\omega_1 = \omega_2','Interpreter','tex')
grid on

subplot(3,2,3)
surf(X,Y,FFT2Analytical,'EdgeColor','none')
zlabel('H_2 Analytical')
 
subplot(3,2,4)
surf(X,Y,FFT2Clean,'EdgeColor','interp')
zlabel('H_2 SNR=\infty','interpreter','tex')

subplot(3,2,5)
surf(X,Y,FFT2Noisy,'EdgeColor','interp')
zlabel('H_2 SNR=10')
xlabel('\omega_1','Interpreter','tex')
ylabel('\omega_2','Interpreter','tex')

subplot(3,2,6)
surf(X,Y,FFT2Noisy,'EdgeColor','interp')
zlabel('H_2 HO.Noise')
xlabel('\omega_1','Interpreter','tex')
ylabel('\omega_2','Interpreter','tex')
