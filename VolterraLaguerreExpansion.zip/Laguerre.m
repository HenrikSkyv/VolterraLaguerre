classdef Laguerre < handle
    %Class structure with different methods and properties
    %The idea is that all data that is processed stays as information in
    %the class. 
    %To get the properties the code is . based:  Volterra.Order = 2
    %An overview of the properties, see under %Properties below
    %
    %All methods can be run by running: 
    % example: Laguerre.TrainLaguerreFull(Input1, Input2, Output, ...)
    % For explanation of the methods, see the documentation on the
    % different methods
    properties
        %%
        %Declearing properties of the class, to make it easily readable
        %Type of Volterra-model
        Memory=NaN;             %Memory of the model
        Order = NaN;            %Model order
        Type = NaN;             %type of model('direct','cross','crossDirect')
        Alpha = NaN;            %Alpha factor
        NumFilt = NaN;          %Number of Laguerrian filters
            
        XReg=NaN;      %Structured regularization matrix of the inputs
        
        HH=NaN;             %Flat structure of the kernel
        HH0=NaN;            %0 order kernel(constant part)
        HH1=NaN;            %1-st order kernel of the first input
        HH2=NaN;            %1st order kernel of the second input
        HH11=NaN;           %2nd-order direct kernel of the first input
        HH21=NaN;           %2nd-order cross kernel
        HH12=NaN;           %2nd-order cross kernel
        HH22=NaN;           %2nd-order direct kernel of the second input
        HH3=NaN;            %Third and higher order kernel information(unstructured)
        IRFFilt=NaN;        %The first order filters

        YPred={};           %The prediction with the validation data(dumps each validation at the end
        
    end
    methods
        function TrainLaguerreFull(obj,Inp1,Inp2,Out1,Memory,order,NumFilt,Alpha,type)
            
            %The Laguerre class has the following training the model
            %TrainLaguerreFull(Input1, Inpu2, Output, Memory, Order,
            %NumberOfLaguerreFIlters, AlphaFactor, Volterra-Type)
            %%%%Inputs:%%%%%
            %Input1 = First input(motion)
            %Input2 = 2nd-input, can be set to empty if 'direct' type is used
            %Output = Vector of outputs for training
            %Memory = Memory lengths of the model(only for plotting the kernels, no
            %effeect in the actual model
            %NumberOfLaguerreFilters = Number of Laguerrian filters to parameteraize
            %the kernel
            %Order = Order of the Volterra-model
            %Alpha = Alpha factor of the model
            %Volterra-type = 'direct'/'cross'/'crossDirect' to decide of the type of
            %the Volterra-model(SISO / Double-input-single-output with cross / double
            %input single-output without cross-terms)
            %%%%%Outputs:%%%%
            %Outputs a trained model, with various properties as kernels. Se the class
            %for all properties
            
            
            %Makes the structured regularization matrix
            [obj.XReg]=InpLaguerre(Inp1,Inp2,order,NumFilt,Alpha,type);
            
            %Trains the model and makes the kernels
            [obj.HH,obj.HH0, obj.HH1, obj.HH2, obj.HH11, obj.HH12, obj.HH21, obj.HH22, obj.HH3, obj.IRFFilt...
                ] = TrainLaguerre(obj.XReg,Out1,Memory,order,NumFilt,Alpha,type);
            
            %Wright the properties
            obj.Memory = Memory;
            obj.Order = order;
            obj.Type = type;
            obj.Alpha = Alpha;
            obj.NumFilt = NumFilt;
        end
           
           
           
        function ValidateLaguerre(obj,InpValid1,InpValid2)
            %Uses the ValidateLaguerre model to make a realization of the already
            %trained model:
            %ValidateLaguerre(Input1,Input2)
            %Input1 = first input of validation data
            %input 2 = second input of validation data(can be empty dependent on the
            %type of model
            
            [XRegVal]=InpLaguerre(InpValid1,InpValid2,obj.Order,obj.NumFilt,obj.Alpha,obj.Type);
            YPredL = XRegVal*obj.HH;
            
            %Wrights the results in a cell-structure
            obj.YPred{end+1}=YPredL;            
        end
    end
    
end