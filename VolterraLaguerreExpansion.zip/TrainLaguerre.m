function [HH,HH0, HH1, HH2, HH11, HH12, HH21, HH22, HH3, IRFFilt] = TrainLaguerre(XReg,Y,Memory,order,NumFilt,Alpha,type)
% Training the Laguerre model
%
%INPUTS
% XReg = regression matrix
% Y = Training data,(Nx1)
%Memory = memory of the system, Integer
%order = order of the system, Integer
% NumFilt = Filter number(Integer)
% Alpha = Damping coefficient (float <0,1>)
% type = type of system, 'direct' 'cross'
%
%Outputs:
%HH = Full structure of output kernel matrix, to be multiplied by Xreg to
%IRFFilt = Impulse response functions of the different filters
% turning the array if not column
if isrow(Y)
    Y = Y';
end
%%
HH=NaN;
HH0=NaN;
HH1=NaN;
HH2=NaN;
HH11=NaN;
HH21=NaN;
HH12=NaN;
HH22=NaN;
HH3=NaN;
IRFFilt=NaN;


%% Train the model
    HH = pinv(XReg)*Y;
%% Getting the IRF from the filters
P = NumFilt-1;
tint = 0:1:Memory;

kalt = 0:1:P;
for m = 1:1:length(kalt)
    k = kalt(m);
    for i = 1:1:length(tint)  
        tau = tint(i);    
        IRFFilt(i,m)=0;
        for j = 0:1:k
            if j>tau
                IRFFilt(i,m)=IRFFilt(i,m);
            else     
                IRFFilt(i,m)= IRFFilt(i,m) + Alpha^((tau-k)/2)*(1-Alpha)^0.5*(-1)^j*nchoosek(tau,j)*nchoosek(k,j)*Alpha^(k-j)*(1-Alpha)^j;  
            end
        end
    end
end

%% Splitting the kernels into Volterra kernels as we know them, using equation 4.74/4.75

%Constant part
HH0 = HH(1);


if strcmp(type,'direct')

    % Linear part:
    HH1 = zeros([Memory+1 1]);
    for j = 1:1:length(kalt)
    HH1 = HH1 + HH(j+1).*IRFFilt(:,j);
    end


    if order > 1
        hhk11=zeros([Memory+1 Memory+1 NumFilt]);
        %Make vector to force fit between HH and the filter used:
        %first elements:
        F1 = [];
        for m = 1:1:NumFilt
        F1 = [F1 repmat(m,[1 NumFilt])]; 
        end
        %Second element
        F2 = repmat(1:1:NumFilt,[1 NumFilt]);

        for m = 1:1:(NumFilt*NumFilt)
            for i = 1:1:(Memory+1)
                for j = 1:1:(Memory+1)
                    hhk11(i,j,m)=HH(m+NumFilt+1)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                end
            end
        end

        HH11 = sum(hhk11,3);

        %Making the snd order kernel symetric
        H11up = triu(HH11,1);
        H11Low = tril(HH11,-1);
        H11Diag = diag(diag(HH11));
        HH11 = (H11up + H11Low + 2.*H11Diag+H11up' + H11Low')./2;      
    end

    if order > 2
        HH3 = HH(NumFilt^2+NumFilt+1:end);
    end
    
    if order == 4    
        warning('4rth order kernel is inside the HH3')    
    end
    
    if order > 5
        
        
        error('5th order and higher is not implemented')    
    end
end

%% Cross implemenation

if strcmp(type,'cross')
    % Linear part:
    HH1 = zeros([Memory+1 1]);
    HH2 = zeros([Memory+1 1]);
    for j = 1:1:length(kalt)
    HH1 = HH1 + HH(j+1).*IRFFilt(:,j);
    HH2 = HH2 + HH(NumFilt+1+1).*IRFFilt(:,j);
    end


    if order > 1
        hhk11=zeros([Memory+1 Memory+1 NumFilt]);
        hhk21=zeros([Memory+1 Memory+1 NumFilt]);   
        hhk12=zeros([Memory+1 Memory+1 NumFilt]);   
        hhk22=zeros([Memory+1 Memory+1 NumFilt]);   
        %Make vector to force fit between HH and the filter used:
        %first elements:
        F1 = [];
        for m = 1:1:NumFilt
        F1 = [F1 repmat(m,[1 NumFilt])]; 
        end
        %Second element
        F2 = repmat(1:1:NumFilt,[1 NumFilt]);

        for m = 1:1:(NumFilt*NumFilt)
            for i = 1:1:(Memory+1)
                for j = 1:1:(Memory+1)
                    hhk11(i,j,m)=HH(m+NumFilt+1)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                    hhk12(i,j,m)=HH(m+NumFilt+1+NumFilt^2)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                    hhk21(i,j,m)=HH(m+NumFilt+1+NumFilt^2*2)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                    hhk22(i,j,m)=HH(m+NumFilt+1+NumFilt^2*3)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                end
            end
        end

        HH11 = sum(hhk11,3);
        HH12 = sum(hhk12,3);
        HH21 = sum(hhk21,3);
        HH22 = sum(hhk22,3);

        %Making the snd order kernel symetric
        HH11 = (triu(HH11,1) + tril(HH11,-1) + 2.*diag(diag(HH11))+triu(HH11,1)' + tril(HH11,-1)')./2;     
        HH12 = (triu(HH12,1) + tril(HH12,-1) + 2.*diag(diag(HH12))+triu(HH12,1)' + tril(HH12,-1)')./2;   
        HH21 = (triu(HH21,1) + tril(HH21,-1) + 2.*diag(diag(HH21))+triu(HH21,1)' + tril(HH21,-1)')./2;   
        HH22 = (triu(HH22,1) + tril(HH22,-1) + 2.*diag(diag(HH22))+triu(HH22,1)' + tril(HH22,-1)')./2;           
       
    end

    if order > 2
        HH3 = HH(1+2*NumFilt+4*NumFilt^2+1:end);
    end
    
    if order == 4    
        warning('4rth order kernel is inside the HH3')    
    end
    
    if order > 5         
        error('5th order and higher is not implemented')    
    end
    
    
    
elseif strcmp(type,'crossDirect')
     % Linear part:
    HH1 = zeros([Memory+1 1]);
    HH2 = zeros([Memory+1 1]);
    for j = 1:1:length(kalt)
    HH1 = HH1 + HH(j+1).*IRFFilt(:,j);
    HH2 = HH2 + HH(NumFilt+1+1).*IRFFilt(:,j);
    end


    if order > 1
        hhk11=zeros([Memory+1 Memory+1 NumFilt]);  
        hhk22=zeros([Memory+1 Memory+1 NumFilt]);   
        %Make vector to force fit between HH and the filter used:
        %first elements:
        F1 = [];
        for m = 1:1:NumFilt
        F1 = [F1 repmat(m,[1 NumFilt])]; 
        end
        %Second element
        F2 = repmat(1:1:NumFilt,[1 NumFilt]);

        for m = 1:1:(NumFilt*NumFilt)
            for i = 1:1:(Memory+1)
                for j = 1:1:(Memory+1)
                    hhk11(i,j,m)=HH(m+NumFilt+1)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                    hhk22(i,j,m)=HH(m+NumFilt+1+NumFilt^2)*IRFFilt(i,F1(m))*IRFFilt(j,F2(m));
                end
            end
        end

        HH11 = sum(hhk11,3);
        HH22 = sum(hhk22,3);

        %Making the snd order kernel symetric
        HH11 = (triu(HH11,1) + tril(HH11,-1) + 2.*diag(diag(HH11))+triu(HH11,1)' + tril(HH11,-1)')./2;     
        HH22 = (triu(HH22,1) + tril(HH22,-1) + 2.*diag(diag(HH22))+triu(HH22,1)' + tril(HH22,-1)')./2;           
       
    end
    
    
    if order > 2
        HH3 = HH(1+2*NumFilt+2*NumFilt^2+1:end);
    end
    
    if order > 3
        warning('4rth order kernel is inside the HH3')     
    end
    
    
    
end
end

