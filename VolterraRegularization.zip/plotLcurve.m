function plotLcurve(fit_err_norm,reg_norm,lambda_squared_mat)

%%
%Function that plots the L-curves
figure(); 
hold on; grid on;
plot(fit_err_norm,reg_norm,'-ob');
xlabel('norm(X*H-F)')
ylabel('norm(L*H)')
set(gca,'XScale','log');
set(gca,'YScale','log');

for j=1:length(lambda_squared_mat)
    
    if mod(j,2)==0; HorizontalAlignment='Left'; Spaces1='   '; Spaces2='   ';
    else HorizontalAlignment='right'; Spaces1=''; Spaces2='   ';
    end
    
    text(fit_err_norm(j),reg_norm(j),[Spaces1 '\lambda^2=' num2str(lambda_squared_mat(j),'%0.0e') Spaces2],'Rotation',45,'HorizontalAlignment',HorizontalAlignment); 
end
end
